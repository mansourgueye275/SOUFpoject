create function st_buffer(geometry, double precision, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_Buffer($1, $2,
		CAST('quad_segs='||CAST($3 AS text) as cstring))

$$;
