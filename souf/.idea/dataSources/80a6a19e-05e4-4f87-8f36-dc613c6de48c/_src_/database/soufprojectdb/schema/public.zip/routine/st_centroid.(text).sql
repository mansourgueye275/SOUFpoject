create function st_centroid(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Centroid($1::public.geometry);
$$;
