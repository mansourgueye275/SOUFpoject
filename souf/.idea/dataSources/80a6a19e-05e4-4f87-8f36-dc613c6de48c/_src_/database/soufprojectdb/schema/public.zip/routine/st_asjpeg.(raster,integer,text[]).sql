create function st_asjpeg(rast raster, nband integer, options text[] DEFAULT NULL::text[]) returns bytea
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.st_asjpeg(st_band($1, $2), $3)
$$;
