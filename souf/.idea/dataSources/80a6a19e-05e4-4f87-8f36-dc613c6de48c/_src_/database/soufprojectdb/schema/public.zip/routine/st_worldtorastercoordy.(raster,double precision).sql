create function st_worldtorastercoordy(rast raster, yw double precision) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT rowy FROM public._ST_worldtorastercoord($1, NULL, $2)
$$;
