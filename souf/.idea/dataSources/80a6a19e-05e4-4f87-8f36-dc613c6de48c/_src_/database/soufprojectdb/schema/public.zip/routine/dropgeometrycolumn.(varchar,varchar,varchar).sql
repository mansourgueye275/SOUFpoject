create function dropgeometrycolumn(schema_name character varying, table_name character varying, column_name character varying) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	ret text;
BEGIN
	SELECT public.DropGeometryColumn('',$1,$2,$3) into ret;
	RETURN ret;
END;
$$;
