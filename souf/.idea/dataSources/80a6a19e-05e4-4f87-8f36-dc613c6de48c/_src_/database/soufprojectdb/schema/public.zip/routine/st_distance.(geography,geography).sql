create function st_distance(geography, geography) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_Distance($1, $2, 0.0, true)
$$;
