create function "_st_countagg_finalfn"(agg agg_count) returns bigint
IMMUTABLE
LANGUAGE plpgsql
AS $$
BEGIN
		IF agg IS NULL THEN
			RAISE EXCEPTION 'Cannot count coverage';
		END IF;

		RETURN agg.count;
	END;

$$;
