create function st_intersects(geography, geography) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Distance($1, $2, 0.0, false) < 0.00001
$$;
