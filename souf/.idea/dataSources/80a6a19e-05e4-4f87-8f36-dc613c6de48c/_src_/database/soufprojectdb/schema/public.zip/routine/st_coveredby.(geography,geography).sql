create function st_coveredby(geography, geography) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($2, $1)
$$;
