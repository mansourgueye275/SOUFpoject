create function st_value(rast raster, x integer, y integer, exclude_nodata_value boolean DEFAULT true) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT st_value($1, 1, $2, $3, $4)
$$;
