create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2017-11-30 17:56:10'::text AS version
$$;
