create function st_maxdistance(geom1 geometry, geom2 geometry) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_MaxDistance(public.ST_ConvexHull($1), public.ST_ConvexHull($2))
$$;
