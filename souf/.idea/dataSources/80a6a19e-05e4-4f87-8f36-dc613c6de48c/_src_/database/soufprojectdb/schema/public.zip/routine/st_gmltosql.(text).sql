create function st_gmltosql(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_GeomFromGML($1, 0)
$$;
