create function st_covers(geography, geography) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($1, $2)
$$;
